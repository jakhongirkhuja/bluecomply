<?php

namespace App\Http\Controllers\Company;

use App\Http\Controllers\Controller;
use App\Http\Requests\Company\StoreClaimRequest;
use App\Models\Company\Claim;
use App\Models\Company\Incident;
use App\Models\Driver\Driver;
use App\Services\Company\ClaimService;
use Illuminate\Http\Response;

class ClaimController extends Controller
{
    public function __construct(protected ClaimService $service)
    {
    }

    public function show($id)
    {
        return response()->success(
            Claim::with('files', 'incident', 'incident.driver')
                ->where('id', $id)
                ->firstOrFail()
        );
    }

    public function store(StoreClaimRequest $request, $company_id)
    {
        $data = $request->validated();

        $driver = Driver::whereKey($data['driver_id'])
            ->where('company_id', $company_id)
            ->whereHas('incidents', fn ($q) =>
            $q->where('id', $data['incident_id'])
            )
            ->firstOrFail();
        $data['company_id'] = $company_id;

        return $this->safe(fn() => response()->success($this->service->store($data, $company_id), Response::HTTP_CREATED));
    }

    // Update an existing claim

    protected function safe(callable $callback)
    {
        try {
            return $callback();
        } catch (\Throwable $e) {
            report($e);

            return response()->error(
                $e->getMessage(),
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }
    }

    // Delete a claim

//    public function update(StoreClaimRequest $request, Claim $claim)
//    {
//        $data = $request->validated();
//
//        return $this->safe(fn() => response()->success(
//            $this->service->update($claim, $data),
//            Response::HTTP_OK
//        )
//        );
//    }

    public function destroy(Claim $claim)
    {
        return $this->safe(fn() => response()->success(
            $this->service->delete($claim),
            Response::HTTP_OK
        )
        );
    }
}
