<?php

namespace App\Models\Company;

use Illuminate\Database\Eloquent\Model;

class Cdlclass extends Model
{
    protected $fillable=['name','short'];
}
