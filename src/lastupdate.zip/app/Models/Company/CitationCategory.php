<?php

namespace App\Models\Company;

use Illuminate\Database\Eloquent\Model;

class CitationCategory extends Model
{
    protected $fillable = [
        'name',
        'description',
    ];


}
