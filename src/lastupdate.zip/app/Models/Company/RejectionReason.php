<?php

namespace App\Models\Company;

use Illuminate\Database\Eloquent\Model;

class RejectionReason extends Model
{
    protected $fillable = ['name'];
}
