<?php

namespace App\Models\Company;

use Illuminate\Database\Eloquent\Model;

class ViolationCategory extends Model
{
    protected $fillable=['name'];
}
