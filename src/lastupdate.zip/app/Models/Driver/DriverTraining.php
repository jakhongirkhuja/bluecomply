<?php

namespace App\Models\Driver;

use Illuminate\Database\Eloquent\Model;

class DriverTraining extends Model
{
    //
}
