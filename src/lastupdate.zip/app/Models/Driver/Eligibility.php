<?php

namespace App\Models\Driver;

use Illuminate\Database\Eloquent\Model;

class Eligibility extends Model
{
    //
}
