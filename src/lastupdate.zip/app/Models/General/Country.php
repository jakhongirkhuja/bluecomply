<?php

namespace App\Models\General;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    //
}
