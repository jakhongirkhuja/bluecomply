<?php

namespace App\Models\General;

use Illuminate\Database\Eloquent\Model;

class VehicleDocumentType extends Model
{
    protected $fillable = [
        'name',
    ];
}
