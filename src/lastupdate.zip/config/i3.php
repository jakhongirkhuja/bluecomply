<?php
return [
    'endpoint' => env('I3_ENDPOINT'),
    'user'     => env('I3_USER'),
    'password' => env('I3_PASSWORD'),
    'account'  => env('I3_ACCOUNT'),
];
